/* bzlib is almost just like zlib.  */

#define BZLIB
#include "gzip.c"
