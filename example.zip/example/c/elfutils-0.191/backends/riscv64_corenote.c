#define BITS 64
#include "riscv_corenote.c"
